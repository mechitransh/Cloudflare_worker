Worker 1 - MP4/B2 Cloudflare Worker
===================================

This version is based on the supplied Worker 1 code.

Changes made:
1. Preserved the existing Backblaze B2 S3/AWS4 signing code.
2. Preserved the existing Range/206 handling and retry logic.
3. Added Access-Control-Expose-Headers for browser video playback.
4. Explicitly adds Accept-Ranges: bytes to successful responses.
5. Made the OPTIONS CORS response explicit for Range/Content-Type/If-Range/Origin.

No autoplay code is included here. Autoplay is controlled by the HTML/video player.

Example:
<video src="https://YOUR-WORKER.example.workers.dev/video.mp4"
       autoplay muted playsinline controls></video>

Required environment variables used by the Worker:
- B2_ENDPOINT
- B2_APPLICATION_KEY_ID
- B2_APPLICATION_KEY
- BUCKET_NAME

Optional variables used by the original Worker include:
- ALLOW_LIST_BUCKET
- RCLONE_DOWNLOAD
- ALLOWED_HEADERS

Do not put B2 credentials directly into index.js.
Configure them as Cloudflare Worker secrets/environment variables.
