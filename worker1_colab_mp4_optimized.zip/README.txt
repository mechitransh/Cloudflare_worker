Worker 1 — MP4-optimized Cloudflare Worker

Files:
- index.js: final optimized Worker code.
- colab_generate_worker1.py: paste this into a Google Colab Python cell. It contains
  the %%writefile /content/cdn/index.js cell and will create the same index.js.

The optimization preserves:
- B2 aws4fetch authentication
- Range forwarding/signing
- 206 / Content-Range handling
- Range retry logic
- HEAD handling
- existing cache architecture
- CORS for browser video playback
- exposed Range-related response headers
- Accept-Ranges: bytes
- MP4 Content-Type fallback
- OPTIONS preflight

Autoplay itself is not controlled by the Worker. Use the HTML video element with
autoplay + muted + playsinline when browser autoplay is required.
