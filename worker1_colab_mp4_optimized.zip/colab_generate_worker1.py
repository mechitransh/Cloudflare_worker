%%writefile /content/cdn/index.js
import { AwsClient } from "aws4fetch";

const UNSIGNABLE_HEADERS = [
    "x-forwarded-proto",
    "x-real-ip",
    "accept-encoding",
    "if-match",
    "if-modified-since",
    "if-none-match",
    "if-range",
    "if-unmodified-since",
];

const HTTPS_PROTOCOL = "https:";
const HTTPS_PORT = "443";
const RANGE_RETRY_ATTEMPTS = 3;
const CDN_CACHE_TTL_SECONDS = 30 * 24 * 60 * 60;
const BROWSER_CACHE_TTL_SECONDS = 1 * 24 * 60 * 60;

function filterHeaders(headers, env) {
    const allowedHeaders = env["ALLOWED_HEADERS"]
        ? env["ALLOWED_HEADERS"].split(",").map(h => h.trim().toLowerCase())
        : null;

    return new Headers(
        Array.from(headers.entries()).filter(([key]) => {
            const lowerKey = key.toLowerCase();

            if (
                UNSIGNABLE_HEADERS.includes(lowerKey) ||
                lowerKey.startsWith("cf-")
            ) {
                return false;
            }

            if (allowedHeaders && !allowedHeaders.includes(lowerKey)) {
                return false;
            }

            return true;
        })
    );
}

function createHeadResponse(response) {
    return new Response(null, {
        headers: new Headers(response.headers),
        status: response.status,
        statusText: response.statusText,
    });
}

function addCacheAndCorsHeaders(response) {
    if (!response.ok) {
        return response;
    }

    const headers = new Headers(response.headers);

    headers.set(
        "Cloudflare-CDN-Cache-Control",
        `public, max-age=${CDN_CACHE_TTL_SECONDS}`
    );

    headers.set(
        "Cache-Control",
        `public, max-age=${BROWSER_CACHE_TTL_SECONDS}`
    );

    headers.set(
        "Access-Control-Allow-Origin",
        "*"
    );

    headers.set(
        "Access-Control-Expose-Headers",
        "Accept-Ranges, Content-Length, Content-Range, Content-Type, ETag"
    );

    headers.set(
        "Accept-Ranges",
        "bytes"
    );

    // Make sure MP4 objects have a browser-friendly content type
    // if the origin did not already provide one.
    if (
        !headers.has("Content-Type") &&
        response.url.toLowerCase().split("?")[0].endsWith(".mp4")
    ) {
        headers.set("Content-Type", "video/mp4");
    }

    return new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers,
    });
}

async function getCachedResponse(request, signedRequest, ctx) {
    const cache = caches.default;

    const cached = await cache.match(request);

    if (cached) {
        return cached;
    }

    const response = await fetch(signedRequest);

    if (response.ok) {
        const responseWithHeaders =
            addCacheAndCorsHeaders(response);

        ctx.waitUntil(
            cache.put(
                request,
                responseWithHeaders.clone()
            )
        );

        return responseWithHeaders;
    }

    return response;
}

function isListBucketRequest(env, path) {
    const pathSegments = path.split("/");

    return (
        (env["BUCKET_NAME"] === "$path" &&
            pathSegments.length < 2) ||
        (env["BUCKET_NAME"] !== "$path" &&
            path.length === 0)
    );
}

export default {
    async fetch(request, env, ctx) {

        // CORS preflight
        if (request.method === "OPTIONS") {
            return new Response(null, {
                status: 204,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods":
                        "GET, HEAD, OPTIONS",
                    "Access-Control-Allow-Headers":
                        "Range, Content-Type, If-Range, Origin",
                    "Access-Control-Expose-Headers":
                        "Accept-Ranges, Content-Length, Content-Range, Content-Type, ETag",
                    "Access-Control-Max-Age": "86400",
                },
            });
        }

        if (!["GET", "HEAD"].includes(request.method)) {
            return new Response(null, {
                status: 405,
                statusText: "Method Not Allowed",
            });
        }

        const url = new URL(request.url);

        url.protocol = HTTPS_PROTOCOL;
        url.port = HTTPS_PORT;

        let path = url.pathname
            .replace(/^\//, "")
            .replace(/\/$/, "");

        if (
            isListBucketRequest(env, path) &&
            String(env["ALLOW_LIST_BUCKET"]) !== "true"
        ) {
            return new Response(null, {
                status: 404,
                statusText: "Not Found",
            });
        }

        const rcloneDownload =
            String(env["RCLONE_DOWNLOAD"]) === "true";

        switch (env["BUCKET_NAME"]) {
            case "$path":
                url.hostname = env["B2_ENDPOINT"];
                break;

            case "$host":
                url.hostname =
                    url.hostname.split(".")[0] +
                    "." +
                    env["B2_ENDPOINT"];
                break;

            default:
                url.hostname =
                    env["BUCKET_NAME"] +
                    "." +
                    env["B2_ENDPOINT"];
                break;
        }

        const headers = filterHeaders(
            request.headers,
            env
        );

        const client = new AwsClient({
            accessKeyId:
                env["B2_APPLICATION_KEY_ID"],

            secretAccessKey:
                env["B2_APPLICATION_KEY"],

            service: "s3",
        });

        const requestMethod = request.method;

        if (rcloneDownload) {
            url.pathname =
                env["BUCKET_NAME"] === "$path"
                    ? path.replace(/^file\//, "")
                    : path.replace(/^file\/[^/]+\//, "");
        }

        // IMPORTANT:
        // The original Range header is preserved and signed by aws4fetch.
        const signedRequest = await client.sign(
            url.toString(),
            {
                method: "GET",
                headers: headers,
            }
        );

        // Range Request handling
        if (signedRequest.headers.has("range")) {

            let attempts = RANGE_RETRY_ATTEMPTS;
            let response;
            let finalResponse;

            do {
                response = await fetch(
                    signedRequest.url,
                    {
                        method: signedRequest.method,
                        headers: signedRequest.headers,
                    }
                );

                if (
                    response.headers.has(
                        "content-range"
                    )
                ) {
                    finalResponse = response;
                    break;
                }

                if (response.ok) {
                    attempts -= 1;

                    if (
                        attempts > 0 &&
                        response.body
                    ) {
                        await response.body.cancel();
                    } else {
                        finalResponse = response;
                    }

                } else {
                    finalResponse = response;
                    break;
                }

            } while (attempts > 0);

            if (!finalResponse) {
                finalResponse = response;
            }

            if (requestMethod === "HEAD") {

                if (finalResponse.body) {
                    await finalResponse.body.cancel();
                }

                return addCacheAndCorsHeaders(
                    createHeadResponse(
                        finalResponse
                    )
                );
            }

            return addCacheAndCorsHeaders(
                finalResponse
            );
        }

        // Full-File HEAD Request handling
        if (requestMethod === "HEAD") {

            const response =
                await fetch(signedRequest);

            if (response.body) {
                await response.body.cancel();
            }

            return addCacheAndCorsHeaders(
                createHeadResponse(response)
            );
        }

        // Full-File GET Request handling
        return await getCachedResponse(
            request,
            signedRequest,
            ctx
        );
    },
};
